document.addEventListener('DOMContentLoaded', function() {
    const sections = document.querySelectorAll('.sticky');

    function checkVisibility() {
        const viewportHeight = window.innerHeight;

        sections.forEach(section => {
            const sectionTop = section.getBoundingClientRect().top;
            const sectionBottom = section.getBoundingClientRect().bottom;

            if (sectionTop < viewportHeight && sectionBottom > 0) {
                section.classList.add('is-visible');
            } else {
                section.classList.remove('is-visible');
            }
        });
    }

    // Check visibility on scroll and resize
    window.addEventListener('scroll', checkVisibility);
    window.addEventListener('resize', checkVisibility);

    // Initial check
    checkVisibility();
});
